﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Dyno.Migrations
{
    public partial class Ninethasasdaasd : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
